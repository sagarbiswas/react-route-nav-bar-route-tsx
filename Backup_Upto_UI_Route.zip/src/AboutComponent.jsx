     import React, { useState } from 'react';
     import ChildComponent from './ChildComponent';
     function AboutComponent() {
        return (
          
            <div style={{backgroundColor:'yellow',maxWidth:'600px',margin:'auto'}}>
            This is about component.
            </div>
        )
     }
        export default AboutComponent;