import React from "react";
import { Navigate, Outlet } from "react-router-dom";

function ProtectedRoute() {
  const isLoggedIn = window.localStorage.getItem("loggedIn");
  console.log("isLoggedIn in ProtectedRoute", isLoggedIn);

  return isLoggedIn === "true" ?
    <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh', maxWidth: '80vh' }}>  <Outlet /></div>
    :

    <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh', maxWidth: '80vh' }}>   <Navigate to="login" /></div>

    ;
}

export default ProtectedRoute;
