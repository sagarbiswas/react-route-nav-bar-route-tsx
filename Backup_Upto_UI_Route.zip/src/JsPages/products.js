function Product() {
  return <h1>Product Page</h1>;
}
export default Product;
