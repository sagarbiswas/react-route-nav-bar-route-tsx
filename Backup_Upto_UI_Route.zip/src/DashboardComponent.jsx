     import React, { useState } from 'react';
     import ChildComponent from './ChildComponent';
     function DashboardComponent() {
        return (
          
            <div style={{backgroundColor:'grey',height:'100%;width:100%;',margin:'auto'}}>
            This is DASHBOARD component.
            </div>
        )
     }
        export default DashboardComponent;