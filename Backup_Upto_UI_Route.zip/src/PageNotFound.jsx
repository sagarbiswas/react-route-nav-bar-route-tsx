     import React, { useState } from 'react';
     import ChildComponent from './ChildComponent';
     function PageNotFoundComponent() {
        return (
          
            <div style={{backgroundColor:'red',maxWidth:'600px',margin:'auto'}}>
            404 Page Not Found.
            </div>
        )
     }
        export default PageNotFoundComponent;