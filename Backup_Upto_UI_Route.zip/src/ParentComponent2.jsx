import React, {
    useRef,
    useImperativeHandle,
    forwardRef
} from 'react';
import ChildComponent2 from './ChildComponent2';
const ParentComponent2 = () => {
    const childRef = useRef();
    const handleClick = () => {
        // Call the exposed function of 
        //the child component to focus the input
        childRef.current.focusInput();
    };

    return (
        <div>
            <ChildComponent2 ref={childRef} />
            <button onClick={handleClick}>
                Focus Input
            </button>
        </div>
    );
};

export default ParentComponent2;