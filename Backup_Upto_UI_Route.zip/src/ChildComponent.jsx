    // // ChildComponent.jsx
    // import React from 'react';

    // function ChildComponent({ onDataSend }) {
    //   const dataToSend = "Hello from Child!";

    //   const handleClick = () => {
    //     onDataSend(dataToSend);
    //   };

    //   return (
    //     <div>
    //       <h2>Child Component</h2>
    //       <button onClick={handleClick}>Send Data to Parent</button>
    //     </div>
    //   );
    // }

    // export default ChildComponent;

    import React from 'react';
    function ChildComponent({ onDataSend }) {
        //const dataToSend = "Hello from Child!";
        const [dataToSend, setData] = React.useState('');
     
        const handleClick = () => {
            onDataSend(dataToSend);
        };

        return (
            
            <div style={{backgroundColor:'grey'}}>
                 <input type="text" value={dataToSend} onChange={(e) => setData(e.target.value)} placeholder="Enter something"/>
                 <br/>
                 <button onClick={handleClick}>Send Data to Parent by clicking this button of Child component</button>
            </div>
        )
    }
    export default ChildComponent;