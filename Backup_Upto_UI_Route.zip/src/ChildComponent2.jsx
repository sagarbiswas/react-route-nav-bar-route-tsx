import React, {
    useRef,
    useImperativeHandle,
    forwardRef
} from 'react';

// Child Component
const ChildComponent2 =
    forwardRef((props, ref) => {
        const inputRef = useRef();

        // Expose specific function to parent
        useImperativeHandle(ref, () => ({
            focusInput: () => {
                inputRef.current.focus();
            }
        }));

        return <div> Child ref component <input ref={inputRef} /> </div>;
    });
export default ChildComponent2;
