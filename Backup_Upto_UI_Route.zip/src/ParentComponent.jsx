    // // ParentComponent.jsx
    // import React, { useState } from 'react';
    // import ChildComponent from './ChildComponent';

    // function ParentComponent() {
    //   const [messageFromChild, setMessageFromChild] = useState('');

    //   const handleChildData = (data) => {
    //     setMessageFromChild(data);
    //   };

    //   return (
    //     <div>
    //       <h1>Parent Component</h1>
    //       <p>Message from Child: {messageFromChild}</p>
    //       <ChildComponent onDataSend={handleChildData} />
    //     </div>
    //   );
    // }

    // export default ParentComponent;

     import React, { useState } from 'react';
     import ChildComponent from './ChildComponent';
     function ParentComponent() {

        const[onMessageReceive,setMessageFromChild]=useState('');
        const handleChildData=(data)=>{
            setMessageFromChild(data + " "+new Date().toLocaleTimeString()  );
        }
        return (
          
            <div style={{backgroundColor:'yellow',maxWidth:'600px',margin:'auto'}}>
            <div>Message from Child is {onMessageReceive}</div>
            <ChildComponent onDataSend={handleChildData} />
          
            </div>
        )
     }
        export default ParentComponent;